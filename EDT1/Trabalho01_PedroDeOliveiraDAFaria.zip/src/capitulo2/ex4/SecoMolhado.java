package capitulo2.ex4;

public interface SecoMolhado {
	public String adicao(int y);
	public String subtracao(int y);
}
