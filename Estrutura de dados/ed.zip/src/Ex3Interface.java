
public interface Ex3Interface {
	public boolean igualdade(double a, double b, double c, double d);
	public double[] adicao(double a, double b, double c, double d);
	public double[] multiplicacao(double a, double b, double c, double d);

}
