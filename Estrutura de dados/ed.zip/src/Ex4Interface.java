
public interface Ex4Interface {
	public String soma(String x, String y);
	public String subtracao(String x, String y);
}
