
public interface Ex5Interface {
	public int operacao1(double i, double j, double k);
	public double operacao2(double i, double j, double k);
	public double operacao3(double i, double j, double k, double a, double b, double c, double d, double p, double q, double r, double s);
	
}
