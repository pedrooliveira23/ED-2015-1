
public interface Ex2Interface {
	public void inserir(int numero);
	public int buscar(int indice);
	public boolean excluir(int indice);
	public boolean estaCheia();
	public void tamanho(int tamanho);
}
